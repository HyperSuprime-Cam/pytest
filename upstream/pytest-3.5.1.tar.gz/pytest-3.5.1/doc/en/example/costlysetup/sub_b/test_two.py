def test_something(setup):
    assert setup.timecostly == 1

def test_something_more(setup):
    assert setup.timecostly == 1

